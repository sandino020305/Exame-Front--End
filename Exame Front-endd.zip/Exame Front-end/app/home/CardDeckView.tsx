'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { CardType } from '@/types/card.types'
import './home.css'

const NAIPES: Record<string, string> = {
  HEARTS: 'Copas',
  DIAMONDS: 'Ouros',
  CLUBS: 'Paus',
  SPADES: 'Espadas',
}

const NAIPE_LIST = ['HEARTS', 'DIAMONDS', 'CLUBS', 'SPADES']

export default function CardDeckView() {
  const [cartas, setCartas] = useState<CardType[]>([])
  const [cartasFiltradas, setCartasFiltradas] = useState<CardType[]>([])
  const [naipeSelecionado, setNaipeSelecionado] = useState('TODOS')
  const [carregando, setCarregando] = useState(true)
  const navegador = useRouter()

  useEffect(() => {
    buscarCartas()
  }, [])

  useEffect(() => {
    if (naipeSelecionado === 'TODOS') {
      setCartasFiltradas(cartas)
    } else {
      setCartasFiltradas(cartas.filter((carta) => carta.suit === naipeSelecionado))
    }
  }, [naipeSelecionado, cartas])

  const buscarCartas = async () => {
    const salvas = localStorage.getItem('cartasBaralho')
    if (salvas) {
      const parseadas = JSON.parse(salvas)
      setCartas(parseadas)
      setCartasFiltradas(parseadas)
      setCarregando(false)
      return
    }

    try {
      const resposta = await fetch(
        'https://deckofcardsapi.com/api/deck/new/draw/?count=52'
      )
      const dados = await resposta.json()

      if (dados.success && dados.cards) {
        setCartas(dados.cards)
        setCartasFiltradas(dados.cards)
        localStorage.setItem('cartasBaralho', JSON.stringify(dados.cards))
      }
    } catch (erro) {
      console.error('Erro:', erro)
    }
    setCarregando(false)
  }

  const embaralhar = () => {
    const novaOrdem = [...cartas]
    for (let i = novaOrdem.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      [novaOrdem[i], novaOrdem[j]] = [novaOrdem[j], novaOrdem[i]]
    }
    setCartas(novaOrdem)
    localStorage.setItem('cartasBaralho', JSON.stringify(novaOrdem))
  }

  const sair = async () => {
    try {
      await fetch('/api/logout', { method: 'POST' })
      localStorage.removeItem('cartasBaralho')
      navegador.push('/auth')
    } catch (erro) {
      console.error('Erro:', erro)
    }
  }

  if (carregando) {
    return (
      <div className="container">
        <div className="loading-text">Carregando...</div>
      </div>
    )
  }

  return (
    <div className="container">
      <div className="top-bar">
        <div className="actions">
          <button onClick={embaralhar} className="btn-embaralhar">
            Embaralhar Cartas
          </button>
          <button onClick={sair} className="btn-sair">
            Logout
          </button>
        </div>
        <h1>Visualização do Baralho</h1>
      </div>

      <div className="filtro-area">
        <label htmlFor="filtro-naipe">Naipe:</label>
        <select
          id="filtro-naipe"
          value={naipeSelecionado}
          onChange={(e) => setNaipeSelecionado(e.target.value)}
          className="select-naipe"
        >
          <option value="TODOS">Todos os naipes</option>
          {NAIPE_LIST.map((naipe) => (
            <option key={naipe} value={naipe}>
              {NAIPES[naipe]}
            </option>
          ))}
        </select>
      </div>

      <div className="grid-cartas">
        {cartasFiltradas.map((carta, indice) => (
          <div key={carta.code + indice} className="carta-box">
            <img src={carta.image} alt={`${carta.value} ${NAIPES[carta.suit]}`} />
            <div className="info-carta">
              <span className="valor-carta">{carta.value}</span>
              <span className="naipe-carta">{NAIPES[carta.suit] || carta.suit}</span>
            </div>
          </div>
        ))}
      </div>

      <footer className="rodape">
        <p>Nome: [Nome Completo]</p>
        <p>RA: [RA]</p>
      </footer>
    </div>
  )
}

